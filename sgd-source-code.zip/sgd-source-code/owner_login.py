import tkinter as tk
from tkinter import messagebox, ttk
from supabase_config import supabase
import socket
import threading


class OwnerLogin:
    def __init__(self, root):
        self.root = root
        self.root.title("SHREE GANESH DIAMOND - Login")
        self.root.state("zoomed")
        self.root.configure(bg="#1c2833")

        # ================= MAIN CONTAINER =================
        self.main_container = tk.Frame(root, bg="#1c2833")
        self.main_container.pack(fill="both", expand=True)

        # ================= CENTER CARD =================
        self.card = tk.Frame(
            self.main_container,
            bg="#ffffff",
            bd=0,
            highlightthickness=0
        )
        self.card.place(relx=0.5, rely=0.5, anchor="center")

        # Border effect
        self.border = tk.Frame(self.card, bg="#3498db", padx=2, pady=2)
        self.border.pack()

        self.content = tk.Frame(
            self.border,
            bg="#ffffff",
            padx=50,
            pady=40
        )
        self.content.pack()

        # ================= HEADER =================
        header = tk.Frame(self.content, bg="white")
        header.pack(pady=(0, 25))

        tk.Label(
            header,
            text="SHREE GANESH DIAMOND",
            font=("Arial", 16, "bold"),
            bg="white",
            fg="#1c2833"
        ).pack()

        ttk.Separator(header).pack(fill="x", pady=8)

        tk.Label(
            header,
            text="LOGIN",
            font=("Arial", 22, "bold"),
            bg="white",
            fg="#2c3e50"
        ).pack()

        # ================= INPUT SECTION =================
        self.input_frame = tk.Frame(self.content, bg="white")
        self.input_frame.pack(fill="x")

        # Email / Mobile
        tk.Label(
            self.input_frame,
            text="Email / Mobile",
            font=("Arial", 10, "bold"),
            bg="white",
            fg="#2c3e50"
        ).pack(anchor="w")

        self.email_frame = tk.Frame(
            self.input_frame,
            bg="#ecf0f1",
            highlightbackground="#bdc3c7",
            highlightthickness=1
        )
        self.email_frame.pack(fill="x", pady=6)

        self.email_entry = tk.Entry(
            self.email_frame,
            bd=0,
            bg="#ecf0f1",
            font=("Arial", 12)
        )
        self.email_entry.pack(fill="x", padx=12, pady=12)

        # Password
        tk.Label(
            self.input_frame,
            text="Password",
            font=("Arial", 10, "bold"),
            bg="white",
            fg="#2c3e50"
        ).pack(anchor="w", pady=(12, 0))

        self.pass_frame = tk.Frame(
            self.input_frame,
            bg="#ecf0f1",
            highlightbackground="#bdc3c7",
            highlightthickness=1
        )
        self.pass_frame.pack(fill="x", pady=6)

        self.password_entry = tk.Entry(
            self.pass_frame,
            bd=0,
            bg="#ecf0f1",
            font=("Arial", 12),
            show="*"
        )
        self.password_entry.pack(fill="x", padx=12, pady=12)

        # ================= LOGIN BUTTON =================
        self.login_button = tk.Button(
            self.content,
            text="LOGIN",
            width=22,
            height=2,
            bg="#1c2833",
            fg="white",
            font=("Arial", 11, "bold"),
            bd=0,
            activebackground="#2c3e50",
            cursor="hand2",
            command=self.login_owner
        )
        self.login_button.pack(pady=25)

        # Hover effect (same color theme)
        self.login_button.bind("<Enter>", lambda e: self.login_button.config(bg="#2c3e50"))
        self.login_button.bind("<Leave>", lambda e: self.login_button.config(bg="#1c2833"))

        # Footer
        tk.Label(
            self.content,
            text="Secure Login System",
            font=("Arial", 9),
            bg="white",
            fg="#7f8c8d"
        ).pack(pady=(10, 0))

        # Enter key binding
        self.root.bind("<Return>", lambda e: self.login_owner())
        self.email_entry.focus_set()

    # ================= INTERNET CHECK =================
    def is_internet_available(self):
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except:
            return False

    # ================= LOGIN LOGIC =================
    def login_owner(self):

        email_or_mobile = self.email_entry.get().strip()
        password = self.password_entry.get().strip()

        if not email_or_mobile or not password:
            messagebox.showerror("Error", "All fields required")
            return

        self.login_button.config(state="disabled", text="Logging in...")
        
        # Run login in separate thread to prevent freezing
        threading.Thread(target=self._process_login, args=(email_or_mobile, password), daemon=True).start()

    def _process_login(self, email_or_mobile, password):
        # Internet check inside thread to prevent freezing
        if not self.is_internet_available():
            self.root.after(0, lambda: self._login_failed("Internet connection is not available.\nPlease check your connection.", "No Internet"))
            return

        # -------- OWNER LOGIN --------
        try:
            auth = supabase.auth.sign_in_with_password({
                "email": email_or_mobile,
                "password": password
            })

            user_id = auth.user.id

            res = supabase.table("users") \
                .select("role, is_active") \
                .eq("id", user_id) \
                .execute()

            if res.data and res.data[0]["role"] == "owner":

                if not res.data[0]["is_active"]:
                    self.root.after(0, lambda: self._login_failed("Inactive Account"))
                    return

                self.root.after(0, self._login_success_owner)
                return

        except Exception as e:
            # If it's a network error, stop here. Don't try manager login (it will also fail).
            err_msg = str(e)
            if "[WinError 10060]" in err_msg or "[WinError 10054]" in err_msg or "timeout" in err_msg.lower() or "connection" in err_msg.lower():
                print(f"Owner Login Network Error: {e}")
                self.root.after(0, lambda: self._login_failed("Server connection failed.\nPlease check your internet.", "Connection Error"))
                return
            # If it's not a network error (e.g. invalid password), proceed to try Manager login
            pass

        # -------- MANAGER LOGIN --------
        try:
            res = supabase.table("managers") \
                .select("id, name, is_allowed_login") \
                .eq("mobile", email_or_mobile) \
                .execute()

            if res.data:

                mgr = res.data[0]

                if not mgr["is_allowed_login"]:
                    self.root.after(0, lambda: self._login_failed("Login not allowed", "Blocked"))

                elif password != "1234":
                    self.root.after(0, lambda: self._login_failed("Invalid password"))

                else:
                    self.root.after(0, lambda: self._login_success_manager(mgr["name"], mgr["id"]))
                    return

            else:
                self.root.after(0, lambda: self._login_failed("Invalid credentials", "Login Failed"))

        except Exception as e:
            print(f"Login Error: {e}")
            self.root.after(0, lambda: self._login_failed("Server connection failed"))

    def _login_success_owner(self):
        messagebox.showinfo("Success", "Owner Login Successful")
        self.root.withdraw()
        self.open_owner_dashboard()

    def _login_success_manager(self, name, mgr_id):
        messagebox.showinfo("Success", f"Welcome {name}")
        self.root.withdraw()
        self.open_manager_dashboard(mgr_id)

    def _login_failed(self, message, title="Error"):
        self.login_button.config(state="normal", text="LOGIN")
        messagebox.showerror(title, message)

    def open_owner_dashboard(self):
        import owner_dashboard
        owner_dashboard.start_dashboard()

    def open_manager_dashboard(self, manager_id):
        import manager_dashboard
        manager_dashboard.start_dashboard(manager_id)
    def on_close(self):
                self.root.quit()   
                self.root.destroy()
                exit()


if __name__ == "__main__":
    root = tk.Tk()
    OwnerLogin(root)
    root.mainloop()
