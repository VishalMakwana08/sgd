import tkinter as tk
from owner_login import OwnerLogin
def start_app():
    root = tk.Tk()
    app = OwnerLogin(root)
    root.mainloop()
def on_close(self):
        self.root.quit()   
        self.root.destroy()
        exit()
if __name__ == "__main__":
    start_app()
