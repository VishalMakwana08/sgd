import tkinter as tk
from tkinter import messagebox, ttk
from supabase_config import supabase


def start_dashboard(manager_id: str):

    root = tk.Tk()
    root.title("SHREE GANESH DIAMOND - Manager Dashboard")
    root.state("zoomed")
    root.configure(bg="#f4f6f7")

    # STYLING (Table Borders)
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Treeview", rowheight=45, font=("Segoe UI", 11), background="white", fieldbackground="white", borderwidth=0)
    style.configure("Treeview.Heading", font=("Segoe UI", 11, "bold"), background="#ecf0f1", foreground="#2c3e50", relief="flat")
    style.map("Treeview", background=[("selected", "#3498db")], foreground=[("selected", "white")])

    # COLORS
    primary_dark = "#1c2833"
    secondary_dark = "#2e4053"
    accent_color = "#34495e"
    light_bg = "#f8f9fa"
    card_bg = "#ffffff"
    text_primary = "#212529"
    text_secondary = "#6c757d"

    # FETCH MANAGER
    mgr = supabase.table("managers") \
        .select("name, categories") \
        .eq("id", manager_id) \
        .single() \
        .execute()

    mgr_name = mgr.data["name"]
    categories = mgr.data["categories"]

    # LOGOUT
    def logout():
        if messagebox.askyesno("Logout", "Are you sure?"):
            root.destroy()
            from main import start_app
            start_app()

    # HEADER
    header = tk.Frame(root, bg=primary_dark, height=70)
    header.pack(fill="x", side="top")

    tk.Label(
        header,
        text=f"💎 SHREE GANESH DIAMOND (MANAGER) | Welcome {mgr_name}",
        bg=primary_dark,
        fg="white",
        font=("Segoe UI", 20, "bold")
    ).pack(side="left", padx=20, pady=10)

    tk.Button(
        header,
        text="Logout",
        bg="#dc3545",
        fg="white", 
        font=("Segoe UI", 10, "bold"),
        relief="raised",
        cursor="hand2",
        padx=15,
        pady=5,
        command=logout
    ).pack(side="right", padx=20, pady=10)

    # SIDEBAR
    menu = tk.Frame(root, bg=secondary_dark, width=250)
    menu.pack(side="left", fill="y")
    menu.pack_propagate(False)

    tk.Label(
        menu,
        text="  MANAGER PANEL",
        bg=secondary_dark,
        fg="#abb2b9",
        font=("Segoe UI", 12, "bold")
    ).pack(pady=30)

    # CONTENT
    content = tk.Frame(root, bg=light_bg)
    content.pack(side="right", fill="both", expand=True)

    def clear_content():
        for w in content.winfo_children():
            w.destroy()

    # HOME
    def show_home():
        clear_content()
        container = tk.Frame(content, bg=light_bg)
        container.pack(fill="both", expand=True, padx=30, pady=20)

        tk.Label(
            container,
            text=f"Welcome, {mgr_name}",
            font=("Segoe UI", 24, "bold"),
            bg=light_bg,
            fg=text_primary
        ).pack(anchor="w", pady=(0, 15))

        clock_label = tk.Label(
            container,
            font=("Arial", 14),
            bg=light_bg,
            fg=text_secondary
        )
        clock_label.pack(anchor="w", pady=(0, 20))

        def update_clock():
            from datetime import datetime
            now = datetime.now()
            formatted = now.strftime("%A, %d %B %Y   |   %I:%M:%S %p")
            try:
                clock_label.config(text=formatted)
                root.after(1000, update_clock)
            except: 
                pass

        update_clock()

        stats_frame = tk.Frame(container, bg=light_bg)
        stats_frame.pack(anchor="w", pady=20, fill="x")

        def create_card(title, value):
            card = tk.Frame(stats_frame, bg=card_bg, bd=0, highlightthickness=1, highlightbackground="#dcdcdc", padx=20, pady=20)
            card.pack(side="left", padx=15, pady=10, fill="y")
            tk.Label(card, text=title.upper(), font=("Segoe UI", 10, "bold"), bg=card_bg, fg=text_secondary).pack(anchor="w", pady=(0, 10))
            value_label = tk.Label(card, text=value, font=("Segoe UI", 24, "bold"), bg=card_bg, fg=primary_dark)
            value_label.pack(anchor="w", pady=(5, 0))
            return value_label

        try:
            res = supabase.table("employees").select("id", count="exact").in_("category", categories).execute()
            total_emp = res.count
        except: 
            total_emp = 0
        create_card("Total Employees", total_emp)

        try:
            from datetime import datetime, timedelta
            today = datetime.now().strftime("%Y-%m-%d")
            res = supabase.table("category_rates").select("category, rate").in_("category", categories).lte("effective_from", today).order("effective_from", desc=True).execute()
            
            latest_rates = {}
            for r in res.data:
                if r['category'] not in latest_rates:
                    latest_rates[r['category']] = r['rate']
            
            rate_text = ", ".join([f"{k}: ₹{v}" for k, v in latest_rates.items()]) if latest_rates else "Not set"
        except: 
            rate_text = "Error"

        create_card("Current Rate", rate_text)
        
        # Last Month Diamonds
        try:
            from datetime import datetime, timedelta
            today_dt = datetime.now().date()
            first_this = today_dt.replace(day=1)
            last_prev = first_this - timedelta(days=1)
            first_prev = last_prev.replace(day=1)
            
            res_last = supabase.table("work_entries").select("quantity").eq("manager_id", manager_id).gte("work_date", first_prev).lte("work_date", last_prev).execute()
            last_total = sum(x['quantity'] for x in res_last.data) if res_last.data else 0
        except:
            last_total = 0
        create_card("Last Month Diamonds", f"{last_total:g}")

        # Tomorrow Total Diamond Work
       # Yesterday's Total Diamond Work
        try:
            from datetime import datetime, timedelta
            today_dt = datetime.now().date()
            # Yahan +1 ki jagah -1 kar diya taaki kal (beete hue din) ka data mile
            yesterday_dt = (today_dt - timedelta(days=1)).strftime("%Y-%m-%d")
            
            res_yest = supabase.table("work_entries") \
                .select("quantity") \
                .eq("manager_id", manager_id) \
                .eq("work_date", yesterday_dt) \
                .execute()
            
            yest_total = sum(float(x['quantity'] or 0) for x in res_yest.data) if res_yest.data else 0
        except Exception as e:
            print(f"Error fetching yesterday work: {e}")
            yest_total = 0
            
        # Card ka title bhi badal kar "Yesterday Work" kar diya
        create_card("Yesterday Work", f"{yest_total:g}")
      # TOP 5 WORKERS (YESTERDAY) - Unique by ID & Category
        try:
            from datetime import datetime, timedelta
            yesterday_dt = (datetime.now().date() - timedelta(days=1)).strftime("%Y-%m-%d")
            
            # Kal ka data fetch karo (Employee details ke saath)
            res_top = supabase.table("work_entries") \
                .select("employee_id, quantity, category, employees(name, emp_number)") \
                .eq("manager_id", manager_id) \
                .eq("work_date", yesterday_dt) \
                .execute()
            
            # Dictionary mein ID ko key banao taaki same name waale alag rahein
            performance = {}
            for entry in res_top.data:
                emp_id = entry['employee_id']
                emp_name = entry['employees']['name']
                emp_num = entry['employees']['emp_number']
                cat = entry['category']
                qty = float(entry['quantity'] or 0)
                
                # Unique key: ID + Category (taaki ek hi worker do category mein ho toh bhi dikhe)
                key = (emp_id, emp_name, emp_num, cat) 
                performance[key] = performance.get(key, 0) + qty
            
            # Sort karo (Quantity ke basis par)
            sorted_workers = sorted(performance.items(), key=lambda x: x[1], reverse=True)[:5]
        except Exception as e:
            print(f"Error: {e}")
            sorted_workers = []

        # --- UI Layout Update ---
        top_frame = tk.LabelFrame(container, text=" ⭐ Top 5 Workers (Yesterday) ", font=("Segoe UI", 12, "bold"), bg=card_bg, fg=primary_dark, padx=15, pady=15, bd=0, highlightthickness=1, highlightbackground="#dcdcdc")
        top_frame.pack(side="left", fill="both", expand=True, padx=15, pady=20)

        if not sorted_workers:
            tk.Label(top_frame, text="No records found", bg=card_bg, fg=text_secondary).pack(pady=20)
        else:
            for i, (info, qty) in enumerate(sorted_workers, 1):
                emp_id, name, num, cat = info # Data unpack kiya
                
                row = tk.Frame(top_frame, bg=card_bg)
                row.pack(fill="x", pady=5)
                
                # Rank, Name [Number] aur Category niche chote font mein
                details_text = f"#{i}  {name} [{num}]"
                lbl_name = tk.Label(row, text=details_text, font=("Segoe UI", 11, "bold"), bg=card_bg, fg=text_primary)
                lbl_name.pack(side="left", anchor="w")
                
                tk.Label(row, text=f"({cat})", font=("Segoe UI", 9), bg=card_bg, fg=text_secondary).pack(side="left", padx=5, pady=(2,0))

                # Total Quantity
                tk.Label(row, text=f"{qty:g} 💎", font=("Segoe UI", 11, "bold"), bg=card_bg, fg="#27ae60").pack(side="right")
                
                if i < len(sorted_workers):
                    tk.Canvas(top_frame, height=1, bg="#f0f0f0", highlightthickness=0).pack(fill="x", pady=2)
    # EMPLOYEE MODULE
    def show_employees():
        clear_content()
        var_id = tk.StringVar()
        var_category = tk.StringVar()
        
        # MEMORY MEIN DATA STORE KARO
        all_employees = []  # Database se ek baar load karo

        # FORM
        form_container = tk.Frame(content, bg=light_bg)
        form_container.pack(side="left", fill="y", padx=20, pady=20)
        
        form = tk.LabelFrame(form_container, text=" Employee Details ", bg=card_bg, padx=20, pady=20, font=("Segoe UI", 12, "bold"), fg=primary_dark, bd=0, highlightthickness=1, highlightbackground="#dcdcdc")
        form.pack(fill="both", expand=True)

        tk.Label(form, text="Employee Number*", bg=card_bg, font=("Segoe UI", 10, "bold"), fg=text_secondary).pack(anchor="w", pady=(0, 5))
        entry_number = tk.Entry(form, font=("Segoe UI", 11), bd=1, relief="solid", highlightthickness=1, highlightcolor="#3498db")
        entry_number.pack(fill="x", pady=(0, 15), ipady=5)

        tk.Label(form, text="Name*", bg=card_bg, font=("Segoe UI", 10, "bold"), fg=text_secondary).pack(anchor="w", pady=(0, 5))
        entry_name = tk.Entry(form, font=("Segoe UI", 11), bd=1, relief="solid", highlightthickness=1, highlightcolor="#3498db")
        entry_name.pack(fill="x", pady=(0, 15), ipady=5)

        tk.Label(form, text="Mobile", bg=card_bg, font=("Segoe UI", 10, "bold"), fg=text_secondary).pack(anchor="w", pady=(0, 5))
        entry_mobile = tk.Entry(form, font=("Segoe UI", 11), bd=1, relief="solid", highlightthickness=1, highlightcolor="#3498db")
        entry_mobile.pack(fill="x", pady=(0, 15), ipady=5)

        tk.Label(form, text="Category*", bg=card_bg, font=("Segoe UI", 10, "bold"), fg=text_secondary).pack(anchor="w", pady=(0, 5))
        cat_combo = ttk.Combobox(form, textvariable=var_category, values=categories, state="readonly", font=("Segoe UI", 11))
        cat_combo.pack(fill="x", pady=(0, 20), ipady=5)
        if categories: 
            var_category.set(categories[0])

        btn_frame = tk.Frame(form, bg=card_bg)
        btn_frame.pack(fill="x", pady=15)

        # TABLE
        table_frame = tk.Frame(content, bg=light_bg)
        table_frame.pack(side="right", fill="both", expand=True, padx=20, pady=20)

        # SEARCH BOX
        search_frame = tk.Frame(table_frame, bg=card_bg, padx=10, pady=10, bd=0, highlightthickness=1, highlightbackground="#dcdcdc")
        search_frame.pack(fill="x", pady=(0, 10))
        tk.Label(search_frame, text="🔍 Search:", bg=card_bg, font=("Segoe UI", 11, "bold"), fg=primary_dark).pack(side="left", padx=(0, 10))
        search_entry = tk.Entry(search_frame, font=("Segoe UI", 11), bd=1, relief="solid", highlightthickness=1, highlightcolor="#3498db")
        search_entry.pack(side="left", fill="x", expand=True, ipady=5)

        tree = ttk.Treeview(table_frame, columns=("id", "number", "name", "mobile", "category"), show="headings", style="Treeview")
        tree.heading("number", text="NUMBER")
        tree.heading("name", text="NAME")
        tree.heading("mobile", text="MOBILE")
        tree.heading("category", text="CATEGORY")
        tree.column("id", width=0, stretch=False)
        tree.column("number", width=120, anchor="center")
        tree.column("name", width=200)
        tree.column("mobile", width=150)
        tree.column("category", width=120)
        tree.pack(fill="both", expand=True)

        def display_records(records_to_show):
            """Treeview mein records dikhao"""
            # Pehle saaf karo
            for item in tree.get_children():
                tree.delete(item)
            
            # Records dikhao
            if records_to_show:
                for emp in records_to_show:
                    tree.insert("", "end", values=(
                        emp["id"], 
                        emp["emp_number"], 
                        emp["name"], 
                        emp["mobile"] or "", 
                        emp["category"]
                    ))

        def filter_data(event=None):
            query = search_entry.get().lower().strip()
            if not query:
                display_records(all_employees)
            else:
                filtered = [
                    e for e in all_employees 
                    if query in str(e.get("emp_number", "")).lower() or 
                       query in str(e.get("name", "")).lower() or 
                       query in str(e.get("mobile") or "").lower()
                ]
                display_records(filtered)
        
        search_entry.bind("<KeyRelease>", filter_data)

        def load_from_database():
            """Sirf ek baar database se load karo"""
            nonlocal all_employees
            try:
                # DATABASE SE EK BAAR LOAD KARO
                res = supabase.table("employees").select("*").eq("manager_id", manager_id).in_("category", categories).order("emp_number").execute()
                all_employees = res.data
                
                # Display karo
                filter_data()
                
                print(f"✅ {len(all_employees)} employees loaded in memory")
                
            except Exception as e: 
                messagebox.showerror("Error", str(e))

        def clear_form():
            var_id.set("")
            entry_number.delete(0, tk.END)
            entry_name.delete(0, tk.END)
            entry_mobile.delete(0, tk.END)
            if categories: 
                var_category.set(categories[0])

        def save():
            number, name, mobile, category = entry_number.get().strip(), entry_name.get().strip(), entry_mobile.get().strip(), var_category.get().strip()
            if number == "" or name == "": 
                messagebox.showerror("Error", "Required fields empty")
                return
            try: 
                num_int = int(number)
            except: 
                messagebox.showerror("Error", "Number must be numeric")
                return

            data = {"emp_number": num_int, "name": name, "mobile": mobile, "category": category, "manager_id": manager_id}
            try:
                if var_id.get(): 
                    supabase.table("employees").update(data).eq("id", var_id.get()).execute()
                else: 
                    supabase.table("employees").insert(data).execute()
                
                messagebox.showinfo("Success", "Employee Saved")
                
                # Database se fresh data load karo
                load_from_database()
                clear_form()
                
            except Exception as e: 
                messagebox.showerror("Database Error", str(e))

        def delete():
            if not var_id.get(): 
                return
            if messagebox.askyesno("Confirm", "Delete employee?"):
                supabase.table("employees").delete().eq("id", var_id.get()).execute()
                
                # Database se fresh data load karo
                load_from_database()
                clear_form()

        def on_tree_select(event):
            selected = tree.selection()
            if not selected:
                return
            values = tree.item(selected[0])["values"]
            # Check if it's not the "No matching records" row
            if values and values[0] != "" and values[1] != "---":
                var_id.set(values[0])
                entry_number.delete(0, tk.END)
                entry_number.insert(0, values[1])
                entry_name.delete(0, tk.END)
                entry_name.insert(0, values[2])
                entry_mobile.delete(0, tk.END)
                entry_mobile.insert(0, values[3] if values[3] != "---" else "")
                var_category.set(values[4])

        tree.bind("<<TreeviewSelect>>", on_tree_select)

        def export_excel():
            if not all_employees:
                messagebox.showwarning("Warning", "No data to export")
                return
            
            from tkinter import filedialog
            import csv
            
            filename = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")],
                title="Export Employees"
            )
            
            if filename:
                try:
                    with open(filename, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.writer(f)
                        writer.writerow(["ID", "Number", "Name", "Mobile", "Category"])
                        for emp in all_employees:
                            writer.writerow([emp.get("id", ""), emp.get("emp_number", ""), emp.get("name", ""), emp.get("mobile", ""), emp.get("category", "")])
                    messagebox.showinfo("Success", "Data exported successfully!")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to export: {str(e)}")

        tk.Button(btn_frame, text="ADD / UPDATE", bg="#28a745", fg="white", font=("Segoe UI", 10, "bold"), height=2, cursor="hand2", command=save, relief="flat").pack(fill="x", pady=5)
        tk.Button(btn_frame, text="DELETE", bg="#dc3545", fg="white", font=("Segoe UI", 10, "bold"), height=2, cursor="hand2", command=delete, relief="flat").pack(fill="x", pady=5)
        tk.Button(btn_frame, text="CLEAR FORM", bg="#6c757d", fg="white", font=("Segoe UI", 10, "bold"), height=2, cursor="hand2", command=clear_form, relief="flat").pack(fill="x", pady=5)
        tk.Button(btn_frame, text="EXPORT EXCEL", bg="#17a2b8", fg="white", font=("Segoe UI", 10, "bold"), height=2, cursor="hand2", command=export_excel, relief="flat").pack(fill="x", pady=5)
        
        # START - Database se load karo
        load_from_database()

    # WORK ENTRY
    def show_work():
        clear_content()
        from datetime import datetime
        from tkcalendar import DateEntry
        selected_date = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))
        
        # MEMORY MEIN DATA STORE KARO
        all_work_data = []  # Saara data memory mein

        # TOP BAR
        top = tk.Frame(content, bg=card_bg, padx=20, pady=15, bd=0, highlightthickness=1, highlightbackground="#dcdcdc")
        top.pack(fill="x", padx=20, pady=10)
        tk.Label(top, text="📅 Work Date:", bg=card_bg, font=("Segoe UI", 12, "bold"), fg=primary_dark).pack(side="left")
        date_picker = DateEntry(top, textvariable=selected_date, date_pattern="yyyy-mm-dd", width=15, font=("Segoe UI", 11))
        date_picker.pack(side="left", padx=10)

        # TABLE
        table_frame = tk.Frame(content, bg="white")
        table_frame.pack(fill="both", expand=True, padx=20, pady=(0, 10))

        # SEARCH BOX
        search_frame = tk.Frame(table_frame, bg="white", pady=10)
        search_frame.pack(fill="x", pady=(0, 10))
        tk.Label(search_frame, text="🔍 Search:", bg="white", font=("Segoe UI", 11, "bold"), fg=primary_dark).pack(side="left", padx=(0, 10))
        search_entry = tk.Entry(search_frame, font=("Segoe UI", 11), bd=1, relief="solid", highlightthickness=1, highlightcolor="#3498db")
        search_entry.pack(side="left", fill="x", expand=True, ipady=5)

        columns = ("emp_id", "number", "name", "category", "qty")
        tree = ttk.Treeview(table_frame, columns=columns, show="headings")
        tree.heading("number", text="NUMBER")
        tree.heading("name", text="NAME")
        tree.heading("category", text="CATEGORY")
        tree.heading("qty", text="QUANTITY")
        tree.column("emp_id", width=0, stretch=False)
        tree.column("number", width=120, anchor="center")
        tree.column("name", width=200)
        tree.column("category", width=120)
        tree.column("qty", width=120, anchor="center")
        tree.pack(fill="both", expand=True)

        def display_work_records(records_to_show):
            """Treeview mein records dikhao"""
            tree.delete(*tree.get_children())
            
            if records_to_show:
                for item in records_to_show:
                    tree.insert("", "end", values=(
                        item["id"], 
                        item["number"], 
                        item["name"], 
                        item["category"], 
                        item["qty"]
                    ))

        def filter_work_data(event=None):
            query = search_entry.get().lower().strip()
            if not query:
                display_work_records(all_work_data)
            else:
                filtered = [
                    item for item in all_work_data
                    if query in str(item.get("number", "")).lower() or 
                       query in str(item.get("name", "")).lower() or 
                       query in str(item.get("category", "")).lower()
                ]
                display_work_records(filtered)
        
        search_entry.bind("<KeyRelease>", filter_work_data)

        def load_work_from_database(*args):
            """Database se ek baar load karo"""
            nonlocal all_work_data
            try:
                # Ensure date is correct from picker
                try:
                    date_val = date_picker.get_date()
                    date_str = date_val.strftime("%Y-%m-%d")
                except:
                    date_str = selected_date.get()
                
                # Sync variable if needed
                if selected_date.get() != date_str:
                    selected_date.set(date_str)

                emp_res = supabase.table("employees").select("id, emp_number, name, category").eq("manager_id", manager_id).order("emp_number").execute()
                work_res = supabase.table("work_entries").select("employee_id, quantity").eq("manager_id", manager_id).eq("work_date", date_str).execute()
                
                w_map = {str(w["employee_id"]): str(w["quantity"]) for w in work_res.data}
                
                # MEMORY MEIN STORE KARO
                all_work_data = [{"id": e["id"], "number": e["emp_number"], "name": e["name"], "category": e["category"], "qty": w_map.get(str(e["id"]), "0")} for e in emp_res.data]
                
                # Display karo
                filter_work_data()
                
            except Exception as e: 
                messagebox.showerror("Error", str(e))

        date_picker.bind("<<DateEntrySelected>>", load_work_from_database)

        def edit_cell(event):
            row = tree.identify_row(event.y)
            column = tree.identify_column(event.x)
            if column != "#5" or not row: 
                return
            
            values = tree.item(row)["values"]
            if values and values[1] == "---":  # Don't edit message row
                return
                
            x, y, width, height = tree.bbox(row, column)
            value = tree.set(row, "qty")
                
            entry = tk.Entry(tree, justify="center")
            entry.place(x=x, y=y, width=width, height=height)
            entry.insert(0, value)
            entry.focus()
            
            def save_edit(event=None):
                if not entry.winfo_exists():
                    return

                new_v = entry.get().strip() or "0"
                try:
                    float(new_v)
                except:
                    messagebox.showerror("Error", "Please enter a valid number")
                    entry.destroy()
                    return
                    
                vals = list(tree.item(row)["values"])
                vals[4] = new_v
                tree.item(row, values=vals)
                
                # Memory mein bhi update karo
                for item in all_work_data:
                    if str(item["id"]) == str(vals[0]): 
                        item["qty"] = new_v
                        break
                
                entry.destroy()
                
            entry.bind("<Return>", save_edit)
            entry.bind("<FocusOut>", save_edit)

        tree.bind("<Double-1>", edit_cell)

        def save_all():
            # Force any active editing to finish (trigger FocusOut)
            root.focus()
            root.update()

            date = selected_date.get()
            try:
                saved_count = 0
                deleted_count = 0
                for row in tree.get_children():
                    v = tree.item(row)["values"]
                    # Skip message row
                    if not v[0] or v[1] == "---":
                        continue
                    
                    try:
                        qty = float(v[4])
                    except:
                        qty = 0.0
                        
                    existing = supabase.table("work_entries").select("id").eq("employee_id", v[0]).eq("work_date", date).execute()
                    
                    if qty > 0:
                        r_res = supabase.table("category_rates").select("rate").eq("category", v[3]).lte("effective_from", date).order("effective_from", desc=True).limit(1).execute()
                        rate = float(r_res.data[0]["rate"]) if r_res.data else 0.0
                        
                        data = {"employee_id": v[0], "manager_id": manager_id, "category": v[3], "quantity": qty, "rate": rate, "work_date": date}
                        if existing.data: 
                            supabase.table("work_entries").update(data).eq("id", existing.data[0]["id"]).execute()
                        else: 
                            supabase.table("work_entries").insert(data).execute()
                        saved_count += 1
                    else:
                        # If quantity is 0, delete the record if it exists
                        if existing.data:
                            supabase.table("work_entries").delete().eq("id", existing.data[0]["id"]).execute()
                            deleted_count += 1
                    
                messagebox.showinfo("Success", f"Saved: {saved_count}, Cleared: {deleted_count}")
                
                # Fresh load from database
                load_work_from_database()
                
            except Exception as e: 
                messagebox.showerror("Database Error", str(e))
        
        tk.Button(content, text="💾 SAVE ALL", bg="#28a745", fg="white", font=("Segoe UI", 11, "bold"), height=2, cursor="hand2", command=save_all, relief="flat").pack(fill="x", padx=20, pady=10)
        
        def export_work_excel():
            data = all_work_data
            if not data:
                messagebox.showwarning("Warning", "No data to export")
                return
                
            from tkinter import filedialog
            import csv
            
            filename = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")],
                title=f"Export Work - {selected_date.get()}"
            )
            
            if filename:
                try:
                    with open(filename, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.writer(f)
                        writer.writerow(["Date", "Number", "Name", "Category", "Quantity"])
                        date_str = selected_date.get()
                        for item in data:
                            writer.writerow([date_str, item.get("number", ""), item.get("name", ""), item.get("category", ""), item.get("qty", "0")])
                    messagebox.showinfo("Success", "Work data exported successfully!")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to export: {str(e)}")

        tk.Button(content, text="📥 EXPORT EXCEL", bg="#17a2b8", fg="white", font=("Segoe UI", 11, "bold"), height=2, cursor="hand2", command=export_work_excel, relief="flat").pack(fill="x", padx=20, pady=(0, 10))
        
        # START - Load from database
        load_work_from_database()

    # NAVIGATION
    def create_nav_btn(text, cmd):
        btn = tk.Button(menu, text=text, bg=secondary_dark, fg="white", font=("Segoe UI", 12), 
                        bd=0, cursor="hand2", activebackground=accent_color, activeforeground="white", 
                        command=cmd, anchor="w", padx=25, height=3)
        btn.pack(fill="x", pady=2)
        btn.bind("<Enter>", lambda e: btn.config(bg=accent_color))
        btn.bind("<Leave>", lambda e: btn.config(bg=secondary_dark))
        return btn

    create_nav_btn("🏠  Home", show_home)
    create_nav_btn("👨‍💼  Employees", show_employees)
    create_nav_btn("🔨  Work Entry", show_work)

    show_home()

    root.mainloop()
