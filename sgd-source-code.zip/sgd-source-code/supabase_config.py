import time

from supabase import create_client, Client
SUPABASE_URL = "https://ywccnkztvdpebyowbqxv.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inl3Y2Nua3p0dmRwZWJ5b3dicXh2Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjY4OTU4MzQsImV4cCI6MjA4MjQ3MTgzNH0.NxjYcwGzbZsDefhhjIKzcpx6_g7u7i2fyx047DLHZeo"
print("Connecting to Supabase...")

start = time.time()

try:
    supabase = create_client(SUPABASE_URL, SUPABASE_KEY)

    # simple query test
    # res = supabase.table("users").select("id").limit(1).execute()
    res = supabase.table("managers").select("id").limit(1).execute()
    print(res)
    end = time.time()

    print("✅ Connected Successfully")
    print("Response Time:", round(end - start, 2), "seconds")

except Exception as e:
    end = time.time()
    print("❌ Connection Failed")
    print("Time Taken:", round(end - start, 2), "seconds")
    print("Error:", e)