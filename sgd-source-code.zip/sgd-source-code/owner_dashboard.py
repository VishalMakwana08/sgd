import tkinter as tk

from tkinter import messagebox, ttk
from supabase import create_client, Client
from datetime import datetime, timedelta
import calendar
from tkcalendar import DateEntry
# ================= SUPABASE CONFIG =================
from supabase_config import SUPABASE_URL, SUPABASE_KEY
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg

try:
    supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)
except Exception as e:
    print(f"Connection Error: {e}")

def start_dashboard():
    root = tk.Tk()
    root.title("SHREE GANESH DIAMOND - Owner Dashboard")
    root.state("zoomed")
    root.configure(bg="#f4f6f7")

    # Color Palette
    primary_dark = "#1c2833"
    secondary_dark = "#2e4053"
    accent_color = "#34495e"
    text_light = "#ffffff"

    # ================= STYLING =================
    style = ttk.Style()
    style.theme_use("clam")
    style.configure("Treeview", background="white", fieldbackground="white", foreground="#333", rowheight=35, font=("Segoe UI", 10), borderwidth=0)
    style.configure("Treeview.Heading", background="#ecf0f1", foreground="#2c3e50", font=("Segoe UI", 10, "bold"), relief="flat")
    style.map("Treeview", background=[("selected", "#3498db")], foreground=[("selected", "white")])

    # ================= LOGOUT FUNCTION =================       
  
    def logout():
        if messagebox.askyesno("Logout", "Are you sure you want to logout?"):
            root.destroy()
            from main import start_app
            start_app()

    # ================= NAVIGATION HELPER =================
    def clear_content():
        for widget in content.winfo_children():
            widget.destroy()

    def show_home_ui():
        clear_content()

        # Main Container
        container = tk.Frame(content, bg="#f4f6f7")
        container.pack(fill="both", expand=True)

        # Header
        header_frame = tk.Frame(container, bg="#f4f6f7")
        header_frame.pack(fill="x", padx=30, pady=(20, 10))

        tk.Label(header_frame, text="📊 Dashboard Overview", font=("Segoe UI", 24, "bold"), bg="#f4f6f7", fg="#2c3e50").pack(side="left")

        # Clock Widget
        clock_lbl = tk.Label(header_frame, font=("Segoe UI", 12), bg="#f4f6f7", fg="#7f8c8d")
        clock_lbl.pack(side="right", anchor="e")

        def update_clock():
            try:
                now = datetime.now()
                clock_lbl.config(text=now.strftime("%d %B %Y | %I:%M:%S %p"))
                clock_lbl.after(1000, update_clock)
            except: pass
        update_clock()

        # --- Data Fetching ---
        yesterday_date = (datetime.now() - timedelta(1)).strftime("%Y-%m-%d")
        
        # Yesterday's Logic
        try:
            y_res = supabase.table("work_entries").select("category, quantity").eq("work_date", yesterday_date).execute()
            y_stats = {"Taliya": 0, "Pel": 0, "Mathala": 0}
            for d in y_res.data:
                if d['category'] in y_stats:
                    y_stats[d['category']] += float(d['quantity'] or 0)
        except:
            y_stats = {"Taliya": 0, "Pel": 0, "Mathala": 0}

        # Last Month Logic
        try:
            today = datetime.now()
            first_day_curr = today.replace(day=1)
            last_day_prev = first_day_curr - timedelta(days=1)
            first_day_prev = last_day_prev.replace(day=1)
            
            m_res = supabase.table("work_entries").select("category, quantity")\
                .gte("work_date", first_day_prev.strftime("%Y-%m-%d"))\
                .lte("work_date", last_day_prev.strftime("%Y-%m-%d")).execute()
            
            m_stats = {"Taliya": 0, "Pel": 0, "Mathala": 0}
            for d in m_res.data:
                if d['category'] in m_stats:
                    m_stats[d['category']] += float(d['quantity'] or 0)
        except:
            m_stats = {"Taliya": 0, "Pel": 0, "Mathala": 0}

        # --- KPI Cards ---
        stats_frame = tk.Frame(container, bg="#f4f6f7")
        stats_frame.pack(fill="x", padx=20, pady=10)

        def create_modern_card(parent, title, stats_dict, icon, color):
            card = tk.Frame(parent, bg="white", padx=20, pady=20)
            card.pack(side="left", fill="both", expand=True, padx=10)
            card.configure(highlightbackground="#e0e0e0", highlightthickness=1)

            # Header
            h_frame = tk.Frame(card, bg="white")
            h_frame.pack(fill="x", pady=(0, 10))
            tk.Label(h_frame, text=icon, font=("Segoe UI", 16), bg="white", fg=color).pack(side="left")
            tk.Label(h_frame, text=title.upper(), font=("Segoe UI", 10, "bold"), bg="white", fg="#95a5a6").pack(side="left", padx=10)

            # Total
            total = sum(stats_dict.values())
            tk.Label(card, text=f"{total:g}", font=("Segoe UI", 26, "bold"), bg="white", fg="#2c3e50").pack(anchor="w")
            tk.Label(card, text="Total Diamonds", font=("Segoe UI", 9), bg="white", fg="#bdc3c7").pack(anchor="w", pady=(0, 15))

            # Breakdown
            for cat, val in stats_dict.items():
                row = tk.Frame(card, bg="white")
                row.pack(fill="x", pady=2)
                tk.Label(row, text=cat, font=("Segoe UI", 9, "bold"), bg="white", fg="#7f8c8d").pack(side="left")
                tk.Label(row, text=f"{val:g}", font=("Segoe UI", 9, "bold"), bg="white", fg=color).pack(side="right")

        create_modern_card(stats_frame, "Yesterday's Production", y_stats, "⚡", "#f39c12")
        create_modern_card(stats_frame, "Last Month Production", m_stats, "📅", "#27ae60")

        # --- Charts Section ---
        charts_frame = tk.Frame(container, bg="#f4f6f7")
        charts_frame.pack(fill="both", expand=True, padx=20, pady=20)

        # Data for charts
        cats = list(y_stats.keys())
        vals = list(y_stats.values())
        colors = ["#3498db", "#e74c3c", "#9b59b6"]

        # 1. Bar Chart
        bar_frame = tk.Frame(charts_frame, bg="white", padx=10, pady=10)
        bar_frame.pack(side="left", fill="both", expand=True, padx=10)
        bar_frame.configure(highlightbackground="#e0e0e0", highlightthickness=1)

        tk.Label(bar_frame, text="Yesterday's Category Wise (Bar)", font=("Segoe UI", 11, "bold"), bg="white", fg="#34495e").pack(anchor="n", pady=5)

        fig_bar = plt.Figure(figsize=(5, 4), dpi=100)
        ax_bar = fig_bar.add_subplot(111)
        bars = ax_bar.bar(cats, vals, color=colors, width=0.5)
        ax_bar.set_facecolor("white")
        fig_bar.patch.set_facecolor("white")
        
        # Labels on bars
        for bar in bars:
            height = bar.get_height()
            ax_bar.text(bar.get_x() + bar.get_width()/2., height, f'{height:g}', ha='center', va='bottom', fontsize=9)
        
        ax_bar.spines['top'].set_visible(False)
        ax_bar.spines['right'].set_visible(False)
        ax_bar.spines['left'].set_visible(False)
        ax_bar.get_yaxis().set_visible(False)
        
        canvas_bar = FigureCanvasTkAgg(fig_bar, bar_frame)
        canvas_bar.get_tk_widget().pack(fill="both", expand=True)

        # 2. Pie Chart
        pie_frame = tk.Frame(charts_frame, bg="white", padx=10, pady=10)
        pie_frame.pack(side="left", fill="both", expand=True, padx=10)
        pie_frame.configure(highlightbackground="#e0e0e0", highlightthickness=1)

        tk.Label(pie_frame, text="Yesterday's Distribution (Pie)", font=("Segoe UI", 11, "bold"), bg="white", fg="#34495e").pack(anchor="n", pady=5)

        fig_pie = plt.Figure(figsize=(5, 4), dpi=100)
        ax_pie = fig_pie.add_subplot(111)
        
        # Filter zeros
        p_vals = [v for v in vals if v > 0]
        p_labels = [c for i, c in enumerate(cats) if vals[i] > 0]
        p_colors = [colors[i] for i, v in enumerate(vals) if v > 0]

        if p_vals:
            wedges, texts, autotexts = ax_pie.pie(p_vals, labels=p_labels, autopct='%1.1f%%', startangle=90, colors=p_colors, textprops=dict(color="#2c3e50"))
            plt.setp(autotexts, size=9, weight="bold", color="white")
        else:
            ax_pie.text(0.5, 0.5, "No Data", ha="center", va="center")

        fig_pie.patch.set_facecolor("white")
        canvas_pie = FigureCanvasTkAgg(fig_pie, pie_frame)
        canvas_pie.get_tk_widget().pack(fill="both", expand=True)

    def show_rates_ui():
        clear_content()

        var_category = tk.StringVar(master=root)
        var_rate = tk.StringVar(master=root)
        var_date = tk.StringVar(master=root, value=datetime.now().strftime("%Y-%m-%d"))

        frame = tk.LabelFrame(
            content,
            text=" Category Rates ",
            bg="white",
            font=("Segoe UI", 12, "bold"),
            padx=25,
            pady=20,
            bd=0,
            highlightthickness=1,
            highlightbackground="#dcdcdc"
        )
        frame.pack(fill="x")
                # -------- CURRENT APPLIED RATES --------
        current_frame = tk.LabelFrame(
            content,
            text=" Current Applied Rates ",
            bg="#f8f9f9",
            font=("Segoe UI", 11, "bold"),
            padx=25,
            pady=15,
            bd=0,
            highlightthickness=1,
            highlightbackground="#dcdcdc"
        )
        current_frame.pack(fill="x", pady=(10, 5))

        rate_labels = {}

        for idx, cat in enumerate(["Taliya", "Pel", "Mathala"]):
            tk.Label(
                current_frame,
                text=f"{cat}:",
                font=("Segoe UI", 10, "bold"),
                bg="#f8f9f9"
            ).grid(row=0, column=idx*2, padx=15, pady=5, sticky="e")

            lbl = tk.Label(
                current_frame,
                text="—",
                font=("Segoe UI", 11),
                fg="#1c2833",
                bg="#f8f9f9"
            )
            lbl.grid(row=0, column=idx*2 + 1, padx=5, sticky="w")

            rate_labels[cat] = lbl

        tk.Label(frame, text="Category", bg="white", font=("Segoe UI", 10)).grid(row=0, column=0, padx=10, pady=10)
        ttk.Combobox(
            frame,
            textvariable=var_category,
            values=["Taliya", "Pel", "Mathala"],
            state="readonly",
            width=18,
            font=("Segoe UI", 10)
        ).grid(row=0, column=1, padx=10)

        tk.Label(frame, text="Rate", bg="white", font=("Segoe UI", 10)).grid(row=0, column=2, padx=10)
        tk.Entry(frame, textvariable=var_rate, width=12, font=("Segoe UI", 10), bd=1, relief="solid").grid(row=0, column=3, padx=10, ipady=3)

        tk.Label(frame, text="Effective From", bg="white", font=("Segoe UI", 10)).grid(row=0, column=4, padx=10)
        DateEntry(frame, textvariable=var_date, width=12, date_pattern="yyyy-mm-dd", font=("Segoe UI", 10)).grid(row=0, column=5, padx=10)
        def load_current_rates():
            today = datetime.now().strftime("%Y-%m-%d")

            for cat, lbl in rate_labels.items():
                res = supabase.table("category_rates") \
                    .select("rate") \
                    .eq("category", cat) \
                    .lte("effective_from", today) \
                    .order("effective_from", desc=True) \
                    .limit(1) \
                    .execute()

                if res.data:
                    lbl.config(text=f"₹ {res.data[0]['rate']}")
                else:
                    lbl.config(text="Not Set")


        def save_rate():
            if not var_category.get() or not var_rate.get():
                messagebox.showwarning("Error", "Category & Rate required")
                return

            try:
                # 1️⃣ Check existing rate for same category + date
                check = supabase.table("category_rates") \
                    .select("id") \
                    .eq("category", var_category.get()) \
                    .eq("effective_from", var_date.get()) \
                    .execute()

                if check.data:
                    # 2️⃣ UPDATE existing rate
                    supabase.table("category_rates") \
                        .update({
                            "rate": float(var_rate.get()),
                            "created_by": "owner"
                        }) \
                        .eq("id", check.data[0]["id"]) \
                        .execute()

                    messagebox.showinfo("Updated", "Rate updated for selected date")

                else:
                    # 3️⃣ INSERT new rate
                    supabase.table("category_rates").insert({
                        "category": var_category.get(),
                        "rate": float(var_rate.get()),
                        "effective_from": var_date.get(),
                        "created_by": "owner"
                    }).execute()

                    messagebox.showinfo("Saved", "New rate added")

                load_rates()
                load_current_rates()

            except Exception as e:
                messagebox.showerror("Error", str(e))


        tk.Button(
            frame,
            text="SAVE RATE",
            bg="#1c2833",
            fg="white",
            font=("Segoe UI", 10, "bold"),
            width=18,
            cursor="hand2",
            command=save_rate
        ).grid(row=0, column=6, padx=20)

        # ---------------- TABLE ----------------
        table_frame = tk.Frame(content, bg="white")
        table_frame.pack(fill="both", expand=True, pady=15)

        cols = ("category", "rate", "effective_from", "created_at")
        tree = ttk.Treeview(table_frame, columns=cols, show="headings")

        for c in cols:
            tree.heading(c, text=c.upper())
            tree.column(c, width=150)

        tree.pack(fill="both", expand=True)

        def load_rates():
            tree.delete(*tree.get_children())
            res = supabase.table("category_rates") \
                .select("*") \
                .order("effective_from", desc=True) \
                .execute()

            for r in res.data:
                tree.insert("", "end", values=(
                    r["category"],
                    r["rate"],
                    r["effective_from"],
                    r["created_at"][:10]
                ))

        load_rates()
        load_current_rates()

    # ================= ATTENDANCE MODULE =================
  # ================= ATTENDANCE MODULE (COUNTS + COLOR LEGEND) =================
    def show_attendance_ui():
        clear_content()
  
        today = datetime.now()
        
        # Fetch Managers
        mgr_res = supabase.table("managers").select("id, name").execute()
        mgr_data = {m['name']: m['id'] for m in mgr_res.data}
        mgr_names = list(mgr_data.keys())

        # --- BOTTOM SECTION: VISUAL REPORT ---
        report_frame = tk.LabelFrame(content, text=" Monthly Attendance History ", bg="white", font=("Segoe UI", 12, "bold"), padx=20, pady=20, bd=0, highlightthickness=1, highlightbackground="#dcdcdc")
        report_frame.pack(fill="both", expand=True)

        filter_bar = tk.Frame(report_frame, bg="white")
        filter_bar.pack(fill="x")

        tk.Label(filter_bar, text="View Manager:", bg="white", font=("Segoe UI", 10)).pack(side="left", padx=10)
        view_mgr_combo = ttk.Combobox(filter_bar, values=mgr_names, state="readonly", width=25, font=("Segoe UI", 10))
        view_mgr_combo.pack(side="left", padx=10)
        if mgr_names: view_mgr_combo.current(0)

        tk.Label(filter_bar, text="Month:", bg="white", font=("Segoe UI", 10)).pack(side="left", padx=10)
        months = list(calendar.month_name)[1:]
        mon_combo = ttk.Combobox(filter_bar, values=months, state="readonly", width=15, font=("Segoe UI", 10))
        mon_combo.set(today.strftime("%B"))
        mon_combo.pack(side="left", padx=10)

        tk.Label(filter_bar, text="Year:", bg="white", font=("Segoe UI", 10)).pack(side="left", padx=10)
        years = [str(y) for y in range(today.year - 5, today.year + 2)]
        year_combo = ttk.Combobox(filter_bar, values=years, state="readonly", width=10, font=("Segoe UI", 10))
        year_combo.set(str(today.year))
        year_combo.pack(side="left", padx=10)

        # --- SUMMARY & LEGEND AREA ---
        info_frame = tk.Frame(report_frame, bg="#f8f9f9", pady=10)
        info_frame.pack(fill="x", pady=10)

        summary_label = tk.Label(info_frame, text="Select a manager to see summary", font=("Segoe UI", 11, "bold"), bg="#f8f9f9", fg="#2874a6")
        summary_label.pack()

        # --- VISUALIZATION CONTAINER (Split View) ---
        viz_container = tk.Frame(report_frame, bg="white")
        viz_container.pack(fill="both", expand=True, pady=10)

        # Left: Heatmap Canvas
        canvas = tk.Canvas(viz_container, bg="white", highlightthickness=0)
        canvas.pack(side="left", fill="both", expand=True)

        # Right: Pie Chart Frame
        chart_frame = tk.Frame(viz_container, bg="white", width=350)
        chart_frame.pack(side="right", fill="y", padx=10)
        chart_frame.pack_propagate(False)

        def open_update_dialog(day):
            mgr_name = view_mgr_combo.get()
            if not mgr_name: return
            
            mgr_id = mgr_data[mgr_name]
            month_idx = months.index(mon_combo.get()) + 1
            year_val = int(year_combo.get())
            
            date_str = f"{year_val}-{month_idx:02d}-{day:02d}"
            
            # Fetch current status safely
            current_status = "full" # Default value
            try:
                res = supabase.table("attendance") \
                    .select("status") \
                    .eq("manager_id", mgr_id) \
                    .eq("attendance_date", date_str) \
                    .execute()

                if res.data:
                    current_status = res.data[0]["status"].lower()
            except Exception as e:
                print("Fetch error:", e)

            dlg = tk.Toplevel(root)
            dlg.title("Update Attendance")
            dlg.geometry("350x450")
            dlg.configure(bg="white")
            dlg.geometry(f"+{root.winfo_x() + 400}+{root.winfo_y() + 200}")

            # Fix: Keep reference to StringVar to prevent garbage collection
            var_status = tk.StringVar(master=dlg, value=current_status)
            dlg.var_status = var_status 

            tk.Label(dlg, text=f"Update for {date_str}", font=("Segoe UI", 14, "bold"), bg="white", fg="#2c3e50").pack(pady=(20, 5))
            tk.Label(dlg, text=f"Manager: {mgr_name}", font=("Segoe UI", 11), bg="white", fg="#7f8c8d").pack(pady=(0, 20))

            # Options List
            opts = [("Full Day", "full", "#2ecc71"), 
                    ("Half Day", "half", "#f1c40f"), 
                    ("Holiday", "holiday", "#95a5a6"), 
                    ("Absent", "absent", "#e74c3c")]
            
            for txt, val, col in opts:
                row = tk.Frame(dlg, bg="white", pady=8)
                row.pack(fill="x", padx=40)
                
                rb = tk.Radiobutton(row, text=txt, variable=var_status, value=val, bg="white", font=("Segoe UI", 12))
                rb.pack(side="left")
                tk.Label(row, bg=col, width=4, height=1).pack(side="right")

            def save():
                try:
                    selected_val = var_status.get()
                    data = {
                        "manager_id": mgr_id,
                        "attendance_date": date_str,
                        "status": selected_val,
                        "marked_by": "owner"
                    }
                    
                    # Upsert
                    supabase.table("attendance") \
                        .upsert(data, on_conflict="manager_id, attendance_date") \
                        .execute()
                    
                    dlg.destroy()
                    draw_heatmap()
                    messagebox.showinfo("Success", "Attendance Updated")

                except Exception as e:
                    messagebox.showerror("Error", f"Update failed: {str(e)}")

            tk.Button(dlg, text="SAVE UPDATE", bg="#2c3e50", fg="white", font=("Segoe UI", 11, "bold"), 
                    command=save, height=2, cursor="hand2").pack(fill="x", padx=40, pady=30)
        def draw_heatmap(event=None):
            canvas.delete("all")
            # Clear previous chart
            for widget in chart_frame.winfo_children():
                widget.destroy()

            name = view_mgr_combo.get()
            if not name: return
            
            m_id = mgr_data[name]
            m_idx = months.index(mon_combo.get()) + 1
            sel_year = int(year_combo.get())
            last_day = calendar.monthrange(sel_year, m_idx)[1]
            
            try:
                res = supabase.table("attendance").select("attendance_date, status").eq("manager_id", m_id).gte("attendance_date", f"{sel_year}-{m_idx:02d}-01").lte("attendance_date", f"{sel_year}-{m_idx:02d}-{last_day}").execute()
                att_data = {datetime.strptime(x['attendance_date'], "%Y-%m-%d").day: x['status'] for x in res.data}
                
                # Calculate Counts
                counts = {"full": 0, "half": 0, "holiday": 0, "absent": 0}
                for s in att_data.values():
                    if s in counts: counts[s] += 1
                
                summary_label.config(text=f"📊 Full: {counts['full']} | Half: {counts['half']} | Holiday: {counts['holiday']} | Absent: {counts['absent']}")
            except: 
                att_data = {}

            # Legend Drawing (Yahan Color Boxes vapas aa gaye)
            colors = {"full": "#2ecc71", "half": "#f1c40f", "holiday": "#95a5a6", "absent": "#e74c3c", "not_marked": "#ebedf0"}
            legend_labels = ["Full Day", "Half Day", "Holiday", "Absent", "Not Marked"]
            
            lx = 50
            for label, key in zip(legend_labels, colors.keys()):
                canvas.create_rectangle(lx, 10, lx+15, 25, fill=colors[key], outline="#d1d5da")
                canvas.create_text(lx+50, 18, text=label, font=("Segoe UI", 9))
                lx += 110

            # Grid Drawing
            box_s, gap = 50, 12
            for i in range(1, last_day + 1):
                col, row = (i - 1) % 7, (i - 1) // 7
                x, y = 50 + col * (box_s + gap), 50 + row * (box_s + gap)
                status = att_data.get(i, "not_marked")
                
                tag = f"day_{i}"
                canvas.create_rectangle(x, y, x+box_s, y+box_s, fill=colors[status], outline="#d1d5da", tags=tag)
                canvas.create_text(x+box_s/2, y+box_s/2, text=str(i), font=("Segoe UI", 10, "bold"), tags=tag)
                
                canvas.tag_bind(tag, "<Button-1>", lambda e, d=i: open_update_dialog(d))
                canvas.tag_bind(tag, "<Enter>", lambda e: canvas.config(cursor="hand2"))
                canvas.tag_bind(tag, "<Leave>", lambda e: canvas.config(cursor=""))

            # --- PIE CHART LOGIC ---
            pie_labels = []
            pie_values = []
            pie_colors = []

            for status, count in counts.items():
                if count > 0:
                    pie_labels.append(status.title())
                    pie_values.append(count)
                    pie_colors.append(colors[status])

            if pie_values:
                fig = plt.Figure(figsize=(3.5, 3.5), dpi=100)
                ax = fig.add_subplot(111)

                def absolute_value(val):
                    a = int(round(val/100.*sum(pie_values)))
                    return f"{a} Days"

                wedges, texts, autotexts = ax.pie(pie_values, labels=pie_labels, autopct=absolute_value, 
                                                  startangle=90, colors=pie_colors, textprops=dict(color="#2c3e50", fontsize=9))
                
                plt.setp(autotexts, size=9, weight="bold", color="white")
                ax.set_title("Attendance Breakdown", fontsize=11, fontweight="bold", color="#2c3e50")
                fig.patch.set_facecolor("white")

                canvas_chart = FigureCanvasTkAgg(fig, chart_frame)
                canvas_chart.get_tk_widget().pack(fill="both", expand=True)
            else:
                tk.Label(chart_frame, text="No attendance marked\nfor this month", bg="white", fg="#95a5a6", font=("Segoe UI", 10)).pack(expand=True)

        view_mgr_combo.bind("<<ComboboxSelected>>", draw_heatmap)
        mon_combo.bind("<<ComboboxSelected>>", draw_heatmap)
        year_combo.bind("<<ComboboxSelected>>", draw_heatmap)
        
        # Initial draw
        if mgr_names: draw_heatmap()

    # ================= ADVANCE UI =================
    def show_advance_ui():
        clear_content()

        # Variables
        var_target_type = tk.StringVar(value="employee")
        var_category_filter = tk.StringVar(value="All")
        var_person_id = tk.StringVar()
        var_amount = tk.StringVar()
        var_note = tk.StringVar()
        var_date = tk.StringVar(value=datetime.now().strftime("%Y-%m-%d"))

        # Main Container
        container = tk.Frame(content, bg="white")
        container.pack(fill="both", expand=True)

        form = tk.LabelFrame(
            container,
            text=" 💸 Add Advance Payment ",
            bg="white",
            font=("Segoe UI", 12, "bold"),
            padx=25,
            pady=25,
            bd=0,
            highlightthickness=1,
            highlightbackground="#dcdcdc"
        )
        form.pack(fill="x", pady=10)

        # Type selection
        tk.Label(form, text="Select Type:", bg="white", font=("Segoe UI", 10))\
            .grid(row=0, column=0, padx=10, pady=10, sticky="w")

        type_combo = ttk.Combobox(
            form,
            textvariable=var_target_type,
            values=["employee", "manager"],
            state="readonly",
            width=18,
            font=("Segoe UI", 10)
        )
        type_combo.grid(row=0, column=1, padx=10)

        # Category filter
        tk.Label(form, text="Filter Category:", bg="white", font=("Segoe UI", 10))\
            .grid(row=0, column=2, padx=20, sticky="w")

        cat_combo = ttk.Combobox(
            form,
            textvariable=var_category_filter,
            values=["All", "Taliya", "Pel", "Mathala"],
            state="readonly",
            width=18,
            font=("Segoe UI", 10)
        )
        cat_combo.grid(row=0, column=3, padx=10)

        # Person selection
        tk.Label(form, text="Select Person:", bg="white", font=("Segoe UI", 10))\
            .grid(row=1, column=0, padx=10, pady=10, sticky="w")

        person_combo = ttk.Combobox(
            form,
            textvariable=var_person_id,
            width=35,
            font=("Segoe UI", 10)
        )
        person_combo.grid(row=1, column=1, columnspan=3, padx=10, sticky="w")

        # Maps
        person_map = {}
        all_persons_data = []

        # Fetch persons
        def fetch_persons(event=None):
            # Clear everything
            var_person_id.set("")
            person_combo.set("")
            person_combo['values'] = []

            person_map.clear()
            all_persons_data.clear()

            target_type = type_combo.get()

            try:
                # MANAGERS
                if target_type == "manager":
                    res = supabase.table("managers")\
                        .select("id, name, categories")\
                        .order("name")\
                        .execute()

                    for m in res.data:
                        display = m['name'].strip()
                        person_map[display] = m['id']

                        # categories might be list or string
                        cats_raw = m.get('categories')
                        cats_list = []
                        if isinstance(cats_raw, list):
                            cats_list = [str(x).strip() for x in cats_raw]
                        elif isinstance(cats_raw, str) and cats_raw:
                            cats_list = [c.strip() for c in cats_raw.split(",") if c.strip()]

                        all_persons_data.append({
                            "name": display,
                            "cats": cats_list
                        })

                # EMPLOYEES
                else:
                    res = supabase.table("employees")\
                        .select("id, name, emp_number, category")\
                        .order("name")\
                        .execute()

                    for e in res.data:
                        display = f"{e['name'].strip()} ({e['emp_number']})"
                        person_map[display] = e['id']
                        cat = (e.get('category') or "").strip()
                        all_persons_data.append({
                            "name": display,
                            "cats": [cat]
                        })

                # Apply filter after fetch
                filter_persons()

            except Exception as e:
                messagebox.showerror("Database Error", str(e))

        # Filter persons
        def filter_persons(event=None):
            if event and event.keysym in ['Return', 'Up', 'Down', 'Tab']:
                return

            search_text = person_combo.get().lower()
            selected_category = cat_combo.get()
            filtered = []

            for person in all_persons_data:
                name = person["name"]
                cats = person["cats"]

                # Category filter
                if selected_category != "All":
                    if selected_category not in cats:
                        continue

                # Search filter
                if search_text:
                    if search_text not in name.lower():
                        continue

                filtered.append(name)

            person_combo['values'] = filtered

        # Bind events
        type_combo.bind("<<ComboboxSelected>>", fetch_persons)
        
        def on_cat_change(event):
            var_person_id.set("")
            filter_persons()
            
        cat_combo.bind("<<ComboboxSelected>>", on_cat_change)
        person_combo.bind("<KeyRelease>", filter_persons)

        # Amount
        tk.Label(form, text="Amount:", bg="white", font=("Segoe UI", 10))\
            .grid(row=2, column=0, padx=10, pady=10, sticky="w")

        amount_entry = tk.Entry(
                    form,
                    textvariable=var_amount,
                    font=("Segoe UI", 10),
                    bd=1, relief="solid"
                )
        amount_entry.grid(row=2, column=1, padx=10, ipady=3)

        # Date
        tk.Label(form, text="Date:", bg="white", font=("Segoe UI", 10))\
            .grid(row=2, column=2, padx=20, sticky="w")

        DateEntry(
            form,
            textvariable=var_date,
            date_pattern="yyyy-mm-dd",
            font=("Segoe UI", 10)
        ).grid(row=2, column=3, padx=10)

        # Note
        tk.Label(form, text="Note:", bg="white", font=("Segoe UI", 10))\
            .grid(row=3, column=0, padx=10, pady=10, sticky="w")

        note_entry = tk.Entry(
            form,
            textvariable=var_note,
            font=("Segoe UI", 10),
            width=45,
            bd=1, relief="solid"
        )
        note_entry.grid(row=3, column=1, columnspan=3, padx=10, sticky="w", ipady=3)

        # Save advance
        def save_advance():
            person_display = person_combo.get().strip()
            selected_pid = None

            # Exact match
            if person_display in person_map:
                selected_pid = person_map[person_display]

            # Case insensitive match
            else:
                for name, pid in person_map.items():
                    if name.lower() == person_display.lower():
                        selected_pid = pid
                        break
            
            if not selected_pid:
                messagebox.showerror(
                    "Error",
                    "Please select a valid person"
                )
                return

          
# remove commas if user enters 1,000
            amount_text = amount_entry.get().strip()
            amount_text = amount_text.replace(",", "")

            if amount_text == "":
                messagebox.showerror("Error", "Amount is required")
                return

            try:
                amount = float(amount_text)
            except ValueError:
                messagebox.showerror("Error", f"Invalid Amount: {amount_text}")
                return

            p_type = type_combo.get()
            data = {
                "person_id": selected_pid,
                "person_type": p_type,
                "amount": amount,
                "remaining_amount": amount,
                "payment_date": var_date.get(),
                "description": note_entry.get(),
                "status": "pending"
            }

            # Fix: Populate specific foreign keys based on type
            if p_type == "manager":
                data["manager_id"] = selected_pid
                data["employee_id"] = None
            else:
                data["employee_id"] = selected_pid
                data["manager_id"] = None

            try:
                supabase.table("advance_payments")\
                    .insert(data)\
                    .execute()

                messagebox.showinfo(
                    "Success",
                    "Advance Added Successfully"
                )

                amount_entry.delete(0, tk.END)
                note_entry.delete(0, tk.END)
                person_combo.set("")

            except Exception as e:
                messagebox.showerror(
                    "Database Error",
                    str(e)
                )

        # Save button
        tk.Button(
            form,
            text="Save Payment",
            command=save_advance,
            bg="#1c2833",
            fg="white",
            font=("Segoe UI", 11, "bold"),
            padx=25,
            pady=8,
            cursor="hand2"
        ).grid(row=4, column=1, columnspan=2, pady=20)

        # Initial load
        fetch_persons()
    # ================= PROFESSIONAL SALARY UI =================
   # ================= PROFESSIONAL SALARY UI =================
  # ================= PROFESSIONAL SALARY UI (UPDATED) =================
    def show_salary_ui():
        clear_content()
        today = datetime.now()
        all_salary_data = [] 

        # ---------- TOP FILTER ----------
        filter_frame = tk.Frame(content, bg="white")
        filter_frame.pack(fill="x", pady=10)

        tk.Label(filter_frame, text="Month:", bg="white", font=("Segoe UI", 10)).pack(side="left", padx=10)
        months = list(calendar.month_name)[1:]
        
        month_var = tk.StringVar(value=today.strftime("%B"))
        month_combo = ttk.Combobox(filter_frame, values=months, textvariable=month_var, state="readonly", width=12, font=("Segoe UI", 10))
        month_combo.pack(side="left")
        month_combo.bind("<<ComboboxSelected>>", lambda e: generate_salary())

        tk.Label(filter_frame, text="Year:", bg="white", font=("Segoe UI", 10)).pack(side="left", padx=10)
        years = [str(y) for y in range(today.year-2, today.year+3)]
        year_var = tk.StringVar(value=str(today.year))
        year_combo = ttk.Combobox(filter_frame, values=years, textvariable=year_var, state="readonly", width=8, font=("Segoe UI", 10))
        year_combo.pack(side="left")
        year_combo.bind("<<ComboboxSelected>>", lambda e: generate_salary())

        tk.Button(
            filter_frame,
            text="🔄 Refresh Data",
            bg="#1c2833",
            fg="white",
            font=("Segoe UI", 10, "bold"),
            cursor="hand2",
            command=lambda: generate_salary()
        ).pack(side="left", padx=15)

        # Current View Label
        current_view_lbl = tk.Label(content, text="", font=("Segoe UI", 14, "bold"), bg="#f4f6f7", fg="#2c3e50")
        current_view_lbl.pack(pady=(0, 10))

        # ---------- SEARCH ----------
        tk.Label(filter_frame, text="🔍 Search:", bg="white", font=("Segoe UI", 10, "bold")).pack(side="left", padx=(30, 5))
        search_entry = tk.Entry(filter_frame, font=("Segoe UI", 10), width=30, bd=1, relief="solid")
        search_entry.pack(side="left", padx=5, ipady=3)

        # ---------- TABLE ----------
        cols = ("person_id", "Name", "Type", "Category", "Earnings", "Advance Balance", "Deduct Advance", "Net Salary", "Status")
        tree = ttk.Treeview(content, columns=cols, show="headings", style="Treeview")
        tree.pack(fill="both", expand=True, pady=10)

        def treeview_sort_column(tv, col, reverse):
            l = [(tv.set(k, col), k) for k in tv.get_children('')]
            try:
                l.sort(key=lambda t: float(t[0]), reverse=reverse)
            except:
                l.sort(key=lambda t: t[0].lower(), reverse=reverse)
            for index, (val, k) in enumerate(l):
                tv.move(k, '', index)
            tv.heading(col, command=lambda: treeview_sort_column(tv, col, not reverse))

        for c in cols:
            tree.heading(c, text=c.upper(), command=lambda _c=c: treeview_sort_column(tree, _c, False))
            tree.column(c, width=100, anchor="center")

        tree.column("person_id", width=0, stretch=False)
        tree.column("Name", width=250, anchor="w")

        def display_salary_records(records):
            tree.delete(*tree.get_children())
            for row in records:
                tree.insert("", "end", values=row)

        def filter_salary(event=None):
            query = search_entry.get().lower().strip()
            if not query:
                display_salary_records(all_salary_data)
            else:
                filtered = [
                    row for row in all_salary_data
                    if query in str(row[1]).lower()
                    or query in str(row[2]).lower()
                    or query in str(row[3]).lower()
                    or query in str(row[8]).lower()
                ]
                display_salary_records(filtered)

        search_entry.bind("<KeyRelease>", filter_salary)

        # ---------- DOUBLE CLICK ----------
        def on_double_click(event):
            item_id = tree.identify_row(event.y)
            column = tree.identify_column(event.x)

            if column == "#7":
                values = list(tree.item(item_id, "values"))
                adv_balance = float(values[5] or 0)

                if adv_balance <= 0:
                    messagebox.showinfo("Note", "No advance balance available.")
                    return
                
                from tkinter import simpledialog
                deduct_amt = simpledialog.askfloat(
                    "Deduct Advance",
                    f"Enter amount to deduct from {values[1]}:",
                    parent=root,
                    minvalue=0,
                    maxvalue=adv_balance
                )

                if deduct_amt is not None:
                    earnings = float(values[4])
                    values[6] = deduct_amt
                    values[7] = earnings - deduct_amt
                    values[5] = adv_balance - deduct_amt   # FIXED LIVE UPDATE

                    tree.item(item_id, values=values)

                    # update master list
                    for i, row in enumerate(all_salary_data):
                        if str(row[0]) == str(values[0]):
                            all_salary_data[i] = tuple(values)
                            break

        tree.bind("<Double-1>", on_double_click)

        # ---------- GENERATE SALARY LOGIC ----------
        def generate_salary():
            nonlocal all_salary_data
            sel_month = month_combo.get()
            sel_year = year_combo.get()

            if not sel_month or not sel_year:
                return
            if sel_month not in months:
                return

            try:
                sel_month = month_combo.get()
                sel_year = year_combo.get()

                current_view_lbl.config(text=f"📄 Salary Sheet: {sel_month} {sel_year} (Loading...)")
                root.update_idletasks()

                all_salary_data.clear()

                month = months.index(sel_month) + 1
                year = int(sel_year)

                month_year = f"{year}-{month:02d}"
                start_date = f"{year}-{month:02d}-01"
                end_date = f"{year}-{month:02d}-{calendar.monthrange(year, month)[1]}"

                # ===============================
                # 1️⃣ FETCH SALARY HISTORY (CURRENT MONTH)
                # ===============================
                hist_res = supabase.table("salary_history")\
                    .select("*")\
                    .eq("month_year", month_year)\
                    .execute()

                history_map = {
                    (str(h["person_id"]), h["person_type"]): h
                    for h in hist_res.data
                }

                # ===============================
                # 2️⃣ FETCH PREVIOUS MONTH CARRY FORWARD
                # ===============================
                prev_month = month - 1
                prev_year = year

                if prev_month == 0:
                    prev_month = 12
                    prev_year -= 1

                prev_month_year = f"{prev_year}-{prev_month:02d}"

                prev_hist_res = supabase.table("salary_history")\
                    .select("person_id, person_type, carry_forward_advance")\
                    .eq("month_year", prev_month_year)\
                    .execute()

                prev_carry_map = {
                    (str(p["person_id"]), p["person_type"]): float(p.get("carry_forward_advance") or 0)
                    for p in prev_hist_res.data
                }

                # ===============================
                # 3️⃣ FETCH WORK ENTRIES (ONLY THIS MONTH)
                # ===============================

            # calculate next month safely
                if month == 12:
                    next_year = year + 1
                    next_month = 1
                else:
                    next_year = year
                    next_month = month + 1

                start_date = f"{year}-{month:02d}-01T00:00:00"
                next_month_start = f"{next_year}-{next_month:02d}-01T00:00:00"

                work_res = supabase.table("work_entries") \
                    .select("employee_id, quantity, rate, work_date") \
                    .gte("work_date", start_date) \
                    .lt("work_date", next_month_start) \
                    .execute()

                emp_earnings = {}

                for w in work_res.data:
                    eid = str(w["employee_id"])
                    qty = float(w.get("quantity") or 0)
                    rate = float(w.get("rate") or 0)

                    emp_earnings[eid] = emp_earnings.get(eid, 0) + (qty * rate)
                                # ===============================
                # FETCH ADVANCE (ONLY UP TO SELECTED MONTH)
                # ===============================

                month_end_date = f"{year}-{month:02d}-{calendar.monthrange(year, month)[1]}"

                adv_res = supabase.table("advance_payments")\
                    .select("person_id, person_type, remaining_amount, payment_date")\
                    .lte("payment_date", month_end_date)\
                    .gt("remaining_amount", 0)\
                    .execute()

                adv_map = {}

                for a in adv_res.data:
                    pid = str(a.get("person_id"))
                    ptype = a.get("person_type")

                    if pid and ptype:
                        key = (pid, ptype)
                        remaining = float(a.get("remaining_amount") or 0)
                        adv_map[key] = adv_map.get(key, 0) + remaining
                # ===============================
                # 5️⃣ MANAGERS
                # ===============================
                mgrs = supabase.table("managers").select("*").execute()

                for m in mgrs.data:
                    mid = str(m["id"])
                    key = (mid, "manager")

                    earnings = float(m.get("salary") or 0)

                    # advance = remaining + previous carry
                    adv = adv_map.get(key, 0) + prev_carry_map.get(key, 0)

                    hist = history_map.get(key, {})
                    deduct = float(hist.get("advance_deducted") or 0)
                    status = hist.get("payment_status", "unpaid")

                    cats_raw = m.get("categories")
                    if isinstance(cats_raw, list):
                        cat_str = ", ".join(cats_raw)
                    else:
                        cat_str = cats_raw or ""

                    all_salary_data.append((
                        mid,
                        m["name"],
                        "Manager",
                        cat_str,
                        earnings,
                        adv,
                        deduct,
                        earnings - deduct,
                        status
                    ))

                # ===============================
                # 6️⃣ EMPLOYEES
                # ===============================
                emps = supabase.table("employees").select("*").execute()

                for e in emps.data:
                    eid = str(e["id"])
                    key = (eid, "employee")

                    earnings = emp_earnings.get(eid, 0)

                    # advance = remaining + previous carry
                    adv = adv_map.get(key, 0) + prev_carry_map.get(key, 0)

                    hist = history_map.get(key, {})
                    deduct = float(hist.get("advance_deducted") or 0)
                    status = hist.get("payment_status", "unpaid")

                    all_salary_data.append((
                        eid,
                        f"{e['name']} ({e['emp_number']})",
                        "Employee",
                        e.get("category", ""),
                        earnings,
                        adv,
                        deduct,
                        earnings - deduct,
                        status
                    ))

                # ===============================
                # 7️⃣ DISPLAY
                # ===============================
                display_salary_records(all_salary_data)

                total_payout = sum(float(row[7]) for row in all_salary_data)

                current_view_lbl.config(
                    text=f"📄 Salary Sheet: {sel_month} {sel_year}   |   Total Net Payout: ₹{total_payout:,.2f}"
                )

                # ===============================
                # 8️⃣ NO WORK ENTRY MESSAGE
                # ===============================
                if not work_res.data:
                    messagebox.showinfo(
                        "No Work Entries",
                        f"No work entries found for {sel_month} {sel_year}.\nEarnings set to 0."
                    )

            except Exception as e:
                messagebox.showerror("Error", str(e))
        # ---------- SAVE ----------
        def save_salary():
            

            selected = tree.selection()
            if not selected:
                return
            
            values = tree.item(selected[0])["values"]

            pid, name, ptype, cat, earnings, adv_bal, deduct, net, status = values

                    # ===============================
        # UPDATE ADVANCE REMAINING AMOUNT
        # ===============================

            deduct_amount = float(deduct)

            if deduct_amount > 0:

                adv_records = supabase.table("advance_payments")\
                    .select("*")\
                    .eq("person_id", pid)\
                    .eq("person_type", ptype.lower())\
                    .gt("remaining_amount", 0)\
                    .order("payment_date")\
                    .execute()

                remaining_to_deduct = deduct_amount

                for adv in adv_records.data:

                    if remaining_to_deduct <= 0:
                        break

                    adv_id = adv["id"]
                    current_remaining = float(adv["remaining_amount"])

                    if current_remaining <= remaining_to_deduct:
                        # fully consume this advance
                        supabase.table("advance_payments")\
                            .update({"remaining_amount": 0})\
                            .eq("id", adv_id)\
                            .execute()

                        remaining_to_deduct -= current_remaining

                    else:
                        # partially deduct
                        new_remaining = current_remaining - remaining_to_deduct

                        supabase.table("advance_payments")\
                            .update({"remaining_amount": new_remaining})\
                            .eq("id", adv_id)\
                            .execute()

                        remaining_to_deduct = 0

            month = months.index(month_var.get()) + 1
            month_year = f"{year_var.get()}-{month:02d}"
            # ===============================
# GET EXISTING SALARY HISTORY
            # ===============================

            existing = supabase.table("salary_history")\
                .select("id, advance_deducted")\
                .eq("person_id", pid)\
                .eq("person_type", ptype.lower())\
                .eq("month_year", month_year)\
                .execute()

            previous_deduct = 0
            history_id = None

            if existing.data:
                history_id = existing.data[0]["id"]
                previous_deduct = float(existing.data[0].get("advance_deducted") or 0)

            # total deduct for this month (cumulative)
            total_deduct = previous_deduct + float(deduct)

            # new net salary after cumulative deduction
            new_net = float(earnings) - total_deduct
            

            try:

                # recompute real advance balance
                adv_check = supabase.table("advance_payments")\
                    .select("remaining_amount")\
                    .eq("person_id", pid)\
                    .eq("person_type", ptype.lower())\
                    .execute()

                real_balance = sum(float(x.get("remaining_amount") or 0) for x in adv_check.data)

                data = {
        "person_id": pid,
        "person_type": ptype.lower(),
        "month_year": month_year,
        "total_earnings": earnings,
        "advance_balance": real_balance,
        "advance_deducted": total_deduct,
        "net_paid": new_net,
        "payment_status": status
    }
                
                check = supabase.table("salary_history").select("id").eq("person_id", pid).eq("person_type", ptype.lower()).eq("month_year", month_year).execute()

                if history_id:
                    supabase.table("salary_history")\
                        .update(data)\
                        .eq("id", history_id)\
                        .execute()
                else:
                    supabase.table("salary_history")\
                        .insert(data)\
                        .execute()

                messagebox.showinfo("Saved", "Salary saved successfully")

            except Exception as e:
                messagebox.showerror("Error", str(e))
            generate_salary()

        def mark_paid():
            selected = tree.selection()
            if not selected: return
            item = list(tree.item(selected[0])["values"])
            month = months.index(month_var.get()) + 1
            month_year = f"{year_var.get()}-{month:02d}"

            try:
                supabase.table("salary_history").update({"payment_status": "paid", "payment_date": datetime.now().strftime("%Y-%m-%d")})\
                    .eq("person_id", item[0]).eq("person_type", item[2].lower()).eq("month_year", month_year).execute()
                
                item[8] = "paid"
                tree.item(selected[0], values=item)
                messagebox.showinfo("Paid", "Salary marked as paid.")
            except Exception as e:
                messagebox.showerror("Error", str(e))

        def export_salary_csv():
            if not all_salary_data:
                messagebox.showwarning("Warning", "No data to export")
                return
            
            from tkinter import filedialog
            import csv
            
            filename = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")],
                title=f"Export Salary - {month_var.get()} {year_var.get()}"
            )
            
            if filename:
                try:
                    with open(filename, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.writer(f)
                        writer.writerow(["ID", "Name", "Type", "Category", "Earnings", "Advance Balance", "Deduct Advance", "Net Salary", "Status"])
                        for row in all_salary_data:
                            writer.writerow(row)
                    messagebox.showinfo("Success", "Salary data exported successfully!")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to export: {str(e)}")

        # ---------- BUTTONS ----------
        btn_frame = tk.Frame(content, bg="white")
        btn_frame.pack(fill="x", pady=5)

        tk.Button(btn_frame, text="💾 Save Salary Record", command=save_salary, bg="#2ecc71", fg="white", font=("Segoe UI", 10, "bold"), cursor="hand2", padx=15, pady=5).pack(side="left", padx=10)
        tk.Button(btn_frame, text="💳 Mark as Paid", command=mark_paid, bg="#3498db", fg="white", font=("Segoe UI", 10, "bold"), cursor="hand2", padx=15, pady=5).pack(side="left")
        tk.Button(btn_frame, text="📥 Export CSV", command=export_salary_csv, bg="#17a2b8", fg="white", font=("Segoe UI", 10, "bold"), cursor="hand2", padx=15, pady=5).pack(side="left", padx=10)

        # Initial Load
        generate_salary()
# ================= MANAGERS MODULE (Your Original Code) =================
    def show_managers_ui():
        clear_content()
        # UI Variables
        var_uuid = tk.StringVar(master=root); var_name = tk.StringVar(master=root); var_mobile = tk.StringVar(master=root)
        var_salary = tk.StringVar(master=root); var_taliya = tk.BooleanVar(master=root); var_pel = tk.BooleanVar(master=root)
        var_mathala = tk.BooleanVar(master=root); var_allowed = tk.BooleanVar(master=root, value=True)

        # Left: Form
        form_frame = tk.LabelFrame(content, text=" Manager Form ", bg="white", font=("Segoe UI", 12, "bold"), padx=20, pady=20, bd=0, highlightthickness=1, highlightbackground="#dcdcdc")
        form_frame.pack(side="left", fill="y", padx=(0, 15))

        def create_lbl_ent(label, var):
            tk.Label(form_frame, text=label, bg="white", font=("Segoe UI", 10)).pack(anchor="w", pady=(10,0))
            tk.Entry(form_frame, textvariable=var, font=("Segoe UI", 10), width=30, bd=1, relief="solid").pack(pady=5, ipady=3)

        create_lbl_ent("Full Name", var_name)
        create_lbl_ent("Mobile Number", var_mobile)
        create_lbl_ent("Salary", var_salary)

        tk.Label(form_frame, text="Category:", bg="white", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(15, 5))
        tk.Checkbutton(form_frame, text="Taliya", variable=var_taliya, bg="white", font=("Segoe UI", 10)).pack(anchor="w")
        tk.Checkbutton(form_frame, text="Pel", variable=var_pel, bg="white", font=("Segoe UI", 10)).pack(anchor="w")
        tk.Checkbutton(form_frame, text="Mathala", variable=var_mathala, bg="white", font=("Segoe UI", 10)).pack(anchor="w")

        tk.Label(form_frame, text="Access:", bg="white", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(15, 5))
        tk.Checkbutton(form_frame, text="Allow Login", variable=var_allowed, bg="white", font=("Segoe UI", 10)).pack(anchor="w")

        # Database Operations inside Managers UI
        def refresh_data():
            tree.delete(*tree.get_children())
            try:
                res = supabase.table("managers").select("*").order("manager_serial").execute()
                for m in res.data:
                    tree.insert("", "end", values=(m['id'], m['manager_serial'], m['name'], m['mobile'], m['salary'], ", ".join(m['categories']), "YES" if m['is_allowed_login'] else "NO"))
            except Exception as e: print(f"Error fetching data: {e}")

        def save_manager():
            if not var_name.get() or not var_mobile.get():
                messagebox.showwarning("Input Error", "Name and Mobile are required!")
                return
            cats = [c for c, v in zip(["Taliya", "Pel", "Mathala"], [var_taliya.get(), var_pel.get(), var_mathala.get()]) if v]
            data = {"name": var_name.get(), "mobile": var_mobile.get(), "salary": float(var_salary.get() or 0), "categories": cats, "is_allowed_login": var_allowed.get()}
            try:
                if var_uuid.get(): supabase.table("managers").update(data).eq("id", var_uuid.get()).execute()
                else: supabase.table("managers").insert(data).execute()
                clear_fields(); refresh_data()
            except Exception as e: messagebox.showerror("Database Error", str(e))

        def delete_manager():
            if not var_uuid.get(): return
            if messagebox.askyesno("Confirm", "Delete this manager?"):
                supabase.table("managers").delete().eq("id", var_uuid.get()).execute()
                clear_fields(); refresh_data()

        def clear_fields():
            var_uuid.set(""); var_name.set(""); var_mobile.set(""); var_salary.set("")
            var_taliya.set(False); var_pel.set(False); var_mathala.set(False); var_allowed.set(True)

        btn_f = tk.Frame(form_frame, bg="white")
        btn_f.pack(pady=20)
        tk.Button(btn_f, text="SAVE", bg="#28b463", fg="white", width=15, font=("Segoe UI", 10, "bold"), cursor="hand2", command=save_manager).pack(pady=5)
        tk.Button(btn_f, text="DELETE", bg="#cb4335", fg="white", width=15, font=("Segoe UI", 10, "bold"), cursor="hand2", command=delete_manager).pack(pady=5)
        tk.Button(btn_f, text="CLEAR", bg="#5d6d7e", fg="white", width=15, font=("Segoe UI", 10, "bold"), cursor="hand2", command=clear_fields).pack(pady=5)

        # Right: Table
        table_frame = tk.Frame(content, bg="white")
        table_frame.pack(side="right", fill="both", expand=True)
        cols = ("uuid", "id", "name", "mobile", "salary", "categories", "login")
        tree = ttk.Treeview(table_frame, columns=cols, show="headings")
        for c in cols[1:]: tree.heading(c, text=c.upper())
        tree.column("uuid", width=0, stretch=False); tree.column("id", width=40)
        tree.pack(fill="both", expand=True)
        
        tree.bind("<<TreeviewSelect>>", lambda e: on_select(tree, var_uuid, var_name, var_mobile, var_salary, var_taliya, var_pel, var_mathala, var_allowed))
        refresh_data()

    def on_select(tree, var_uuid, var_name, var_mobile, var_salary, var_taliya, var_pel, var_mathala, var_allowed):
        sel = tree.selection()
        if not sel: return
        val = tree.item(sel[0])['values']
        var_uuid.set(val[0]); var_name.set(val[2]); var_mobile.set(val[3]); var_salary.set(val[4])
        var_taliya.set("Taliya" in str(val[5])); var_pel.set("Pel" in str(val[5])); var_mathala.set("Mathala" in str(val[5]))
        var_allowed.set(val[6] == "YES")

    # ================= HEADER =================
    header = tk.Frame(root, bg=primary_dark, height=80)
    header.pack(side="top", fill="x")
    tk.Label(header, text="💎 SHREE GANESH DIAMOND (OWNER)", bg=primary_dark, fg=text_light, 
             font=("Segoe UI", 22, "bold")).pack(side="left", padx=30, pady=15)
    tk.Button(
    header,
    text="🚪 Logout",
    bg="#c0392b",
    fg="white",
    font=("Segoe UI", 10, "bold"),
    padx=15,
    pady=6,
    relief="flat",
    cursor="hand2",
    command=logout
).pack(side="right", padx=20)


    # ================= MAIN LAYOUT =================
    menu = tk.Frame(root, bg=secondary_dark, width=250)
    menu.pack(side="left", fill="y")
    menu.pack_propagate(False)

    content = tk.Frame(root, bg="#f4f6f7", padx=20, pady=20)
    content.pack(side="right", fill="both", expand=True)

    tk.Label(menu, text="OWNER PANEL", fg="#abb2b9", bg=secondary_dark, font=("Segoe UI", 11, "bold")).pack(pady=30)
    
    # Sidebar Buttons
    tk.Button(menu, text="🏠  Home", bg=accent_color, fg="white", font=("Segoe UI", 11), relief="flat", height=2, anchor="w", padx=25, cursor="hand2", command=show_home_ui).pack(fill="x", pady=2)
    tk.Button(menu, text="📊  Managers", bg=accent_color, fg="white", font=("Segoe UI", 11), relief="flat", height=2, anchor="w", padx=25, cursor="hand2", command=show_managers_ui).pack(fill="x", pady=2)
    tk.Button(menu, text="📅  Attendance", bg=accent_color, fg="white", font=("Segoe UI", 11), relief="flat", height=2, anchor="w", padx=25, cursor="hand2", command=show_attendance_ui).pack(fill="x", pady=2)
    tk.Button(
    menu,
    text="💰  Rates",
    bg=accent_color,
    fg="white",
    font=("Segoe UI", 11),
    relief="flat",
    height=2,
    anchor="w",
    padx=25,
    cursor="hand2",
    command=show_rates_ui
).pack(fill="x", pady=2)
    tk.Button(
    menu,
    text="💸  Advance",
    bg=accent_color,
    fg="white",
    font=("Segoe UI", 11),
    relief="flat",
    height=2,
    anchor="w",
    padx=25,
    cursor="hand2",
    command=show_advance_ui
).pack(fill="x", pady=2)
    tk.Button(
    menu,
    text="💵  Salary",
    bg=accent_color,
    fg="white",
    font=("Segoe UI", 11),
    relief="flat",
    height=2,
    anchor="w",
    padx=25,
    cursor="hand2",
    command=show_salary_ui
).pack(fill="x", pady=2)

    show_home_ui() # Default
    root.mainloop()
